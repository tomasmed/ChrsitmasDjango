from django.contrib import admin
from .models import Pet,Type

admin.site.register(Pet)
admin.site.register(Type)
# Register your models here.
